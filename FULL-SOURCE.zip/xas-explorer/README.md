> This is the complete authoring archive. For the browser-upload publishing route, follow START-HERE.md in the APS Presentation Kit. Its site lives in docs/; this authoring project uses dist/.

# APS X-ray absorption explorer

An interactive first deliverable for **GUP38672_2014-2_12-BM**, acquired at APS in 2014. The website makes the original scans discoverable and comparable, with an explicit record of how each plotted value was obtained.

## Present it

1. Start with **Zn** and all samples: nine individual scans across J14, T1, and T20.
2. Click a sample × element cell to focus the comparison.
3. Switch from the near-edge window to the full acquisition range. Every acquired point is retained, with its real energy spacing.
4. Compare fluorescence A/I0, fluorescence B/I0, recorded μ channels, and I0. Use relative energy to inspect the nominal edge.
5. Select one source scan, export the plotted CSV, or download the original SPEC file.
6. Open **Dataset & methods** to show the source inventory and unresolved metadata issues.

The coverage map represents **which sample–element combinations were measured**. It is not a spatial map, elemental abundance map, or fitted structural model. No spatial grid or sample composition descriptions were supplied.

## Run locally

No installation or build is needed to view the included distribution. From this directory:

```sh
python3 -m http.server 4173 --bind 127.0.0.1 --directory dist
```

Open http://127.0.0.1:4173/ in a browser. Serve the whole `dist` directory; opening `index.html` directly will not load the JSON sidecar correctly.

## Publish on GitHub Pages

The supplied `.github/workflows/pages.yml` deploys the already-built `dist` folder. No server, database, API key, or scientific software installation is needed for visitors.

1. Put the contents of this directory into the intended GitHub repository on its `main` branch, including `dist`, source files, and the `.github` directory.
2. Under **Settings → Pages**, choose **GitHub Actions** as the source.
3. Push to `main` or run **Publish dataset explorer** from Actions.
4. Use the Pages URL returned by the completed deployment.

This package has **not been uploaded or published**. No repository destination was supplied. Public Pages deployment exposes the included dataset and original files; choose the publication audience with the dataset owner. The existing dataset license/redistribution terms were not supplied, so no new license has been asserted.

Workflow follows [GitHub's official Pages documentation](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages).

## Dataset

| Scope | Count |
|---|---:|
| Original files, excluding `.DS_Store` | 39 |
| Main spectroscopy scans | 33 |
| Main measurement points | 15,939 |
| All parsed acquisition blocks | 52 |
| All acquisition rows, including setup | 17,872 |
| Supplementary/setup blocks | 19 |

| Sample label | Fe | Co | Ni | Cu | Zn | Ga |
|---|---:|---:|---:|---:|---:|---:|
| J14 | — | 3 | 3 | 3 | 3 | — |
| T1 | 3 | — | — | 3 | 3 | — |
| T20 | — | — | 3 | 3 | 3 | 3 |

Each main spectrum has 483 points and 55 recorded columns. The explorer includes six selectable channels; all recorded columns remain in the downloadable original files. Unmeasured combinations stay empty. Dates come from SPEC `#D` headers: July 28, 2014, with no timezone supplied.

## Processing and interpretation

- Parse each SPEC `#S` block independently; validate both `#N` and `#L` against every numeric row. Beamline macros are read as evidence, never executed.
- Keep `exafsscan` blocks from the three main sample folders as the main dataset. Preserve the remaining blocks in the supplemental inventory.
- Convert energy and the nominal edge from the supplied keV scale to eV by multiplying by 1,000.
- `fluoA = flatot / i0`; `fluoB = flbtot / i0`. The measured I0 is positive throughout the main collection.
- `relativeEv = energyEv − nominalEdgeEv`. The nominal edge comes from the header, not a fit.
- Keep μ01, μ12, μ23, I0, and acquisition time as recorded. Preserve individual scans; do not average, smooth, resample, or infer uncertainties.
- Fluorescence ratios are uncorrected and are **not concentrations or edge-step-normalized absorption**. No reference calibration, dead-time correction, self-absorption correction, pre-edge subtraction, EXAFS extraction, Fourier transform, or FEFF fit is included.
- Comparisons of amplitudes need experimental context, including sample thickness and detector conditions. Labels a/b/c have unspecified experimental meaning and are not claimed to be replicates or positions.

### Metadata to resolve

1. `J14_Cu a .4`, `J14_Cu b .6`, and `J14_Cu c .5` have `T20_Cu` file headers. The UI uses the supplied folder assignment and flags the conflict.
2. J14 Ni contains two distinct scans labelled `b`, numbers 3 and 4. Both are retained.
3. `T1_Cu c .3` contains a 483-point spectrum followed by a 51-point slit alignment scan. They are parsed separately.
4. SPEC `#E` timestamps are inconsistent with `#D`. The UI uses `#D` and does not manufacture a timezone or a corrected timestamp.

## Reproduce and revise

- `public/raw/`: original files, preserved byte-for-byte.
- `tools/ingest.py`: standalone Python parser; rebuilds a reviewed snapshot while preserving existing app identity and filters.
- `src/data.json`: reviewed measurements, catalog, inventory, SHA-256 provenance, and definitions.
- `src/content/dashboard/`: authored React interface and responsive styles.
- `src/theme.css`: editable theme tokens.
- `dist/`: compiled static site, JSON sidecar, and download assets.

Recreate the data using only Python's standard library:

```sh
python3 tools/ingest.py public/raw src/data.json
python3 tools/validate.py
```

The authoring project uses the bundled Data runtime. Follow `AGENTS.md` for its installed-runtime build command. After a build, run `python3 tools/copy_assets.py` to include download assets. Before final delivery, set `buildStatus` in `src/data.json` to `complete` and rebuild. The GitHub workflow deploys the committed distribution and does not rebuild source edits automatically.

The main sample and element filters, selected signal, energy window, relative-energy setting, and single-scan selection use the app's view-state mechanism. Copy links carry the current view. Hosted GitHub Pages remains a static snapshot; edits are viewer-local, and scientific data refreshes require regenerating and deploying the distribution. Codex-specific editing/export handoffs are available only in a compatible host; the spectrum controls, CSV export, and original downloads run in a normal browser.

## Verification

Completed: successful compiled build and runtime integrity verification; 33 unique scan IDs; all 15,939 main points reconciled; energy monotonicity; finite numeric rows; I0 positivity; both fluorescence ratios and relative energies checked; extra alignment block excluded; all 39 copied originals verified by SHA-256; local HTTP endpoint returned 200. Static execution checked 288 element/sample/window/channel combinations, empty selections, the methods inventory, single-scan mode, relative energy, and reset; all emitted spectrum paths had finite coordinates. This component-level check used lightweight runtime stand-ins and does not verify actual browser or shared-runtime behavior.

Automated browser inspection was blocked by this session's browser URL policy. Desktop/mobile appearance, browser interactions, and native source-inspector controls have **not** been visually verified. Open the preview and exercise the walkthrough before presenting. The local build and static checks do not substitute for that visual review.

## Recommended tools

- **Already sufficient:** Data for inspected datasets and visuals, GitHub for versioning/publication, and the current static web interface.
- **Larch:** the next scientific-processing layer for energy calibration, normalization, χ(k), Fourier transforms, and reproducible XAS analysis. It is a scientific Python package/application, not a Codex plugin. [Official documentation](https://xraypy.github.io/xraylarch/).
- **Demeter / FEFF:** complementary analysis and modelling references, rather than web-interface plugins. [Demeter](https://bruceravel.github.io/demeter/) · [FEFF](https://feff.phys.washington.edu/).
